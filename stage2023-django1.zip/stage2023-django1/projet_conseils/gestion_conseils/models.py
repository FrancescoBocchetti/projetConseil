from django.db import models


class Civilite(models.Model):
    libelle = models.CharField(max_length=5)
    libelle_long = models.CharField("Civilité", max_length=20)

    def __str__(self):
        return self.libelle
    

class Membre(models.Model):
    civilite = models.ForeignKey(Civilite, null=True, on_delete=models.SET_NULL)
    nom = models.CharField(max_length=200)
    prenom = models.CharField(max_length=200, default='', blank=True)
    mail = models.EmailField(max_length=200, default='', blank=True)
    telephone_1= models.CharField("Téléphone 1", max_length=20, default='', blank=True)
    telephone_2 = models.CharField("Téléphone 2", max_length=20, default='', blank=True)
    adr_2 = models.CharField("info complémentaire appartement", max_length=200, default='', blank=True)
    adr_3 = models.CharField("info complémentaire residence", max_length=200, default='', blank=True)
    adr_4 = models.CharField("adresse voie", max_length=200, default='', blank=True)
    adr_5 = models.CharField("Lieu dit", max_length=200, default='', blank=True)
    cp = models.CharField(max_length=5,default='', blank=True)
    ville = models.CharField(max_length=50, default='', blank=True)
    creation = models.DateTimeField(auto_now_add=True, null=True)
    modification = models.DateTimeField(auto_now=True, null=True)
    
    def __str__(self):
        if self.prenom:
            return '{} {}'.format(self.nom, self.prenom)
        return self.nom


class Quartier(models.Model):
    nom_quartier = models.CharField(max_length=200, default='', null=True, blank=True)
    creation = models.DateTimeField(auto_now_add=True, null=True)
    modification = models.DateTimeField(auto_now=True, null=True)

    membre = models.ManyToManyField(
        Membre,
        through="Inscription",
        through_fields=("quartier", "membre"),
        related_name="quartiers"
        )

    def __str__(self):
        return self.nom_quartier
    
    
class Role(models.Model):
    libelle_role = models.CharField(max_length=50, default='', null=True, blank=True)

    membre = models.ManyToManyField(
        Membre,
        through="Inscription",
        through_fields=("role", "membre"),
        related_name="roles"
        )
    
    def __str__(self):
        return self.libelle_role
    

class Inscription(models.Model):
    quartier = models.ForeignKey(Quartier, on_delete=models.SET_NULL, default='', null=True, blank=True)
    membre = models.ForeignKey(Membre, on_delete=models.CASCADE)
    role = models.ForeignKey(Role, null=True, on_delete=models.SET_NULL, default='', blank=True)
    date_entree = models.DateField("date entrée", null=True, blank=True)
    date_sortie = models.DateField("date sortie", null=True, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=['quartier', 'membre',], name='unique_quartier_membre'
            )
        ]

    def __str__(self):
        return "{}:{}".format(self.quartier, self.membre)
