from django.contrib import admin

from .models import Civilite, Quartier, Membre, Role, Inscription

import locale

class InscriptionInline(admin.TabularInline):
    model = Inscription
    extra = 1

class MembreInline(admin.TabularInline):
    model = Membre
    extra = 1

admin.site.register(Role)


@admin.register(Civilite)
class CiviliteAdmin(admin.ModelAdmin):
    list_display = ['libelle','libelle_long']
    list_display_links = ['libelle','libelle_long']


@admin.register(Membre)
class MembreAdmin(admin.ModelAdmin):
    inlines = [InscriptionInline]
    list_display = ['civilite','nom', 'prenom', 'mail', 'modification']
    list_display_links = ['nom']
    list_filter = ["quartiers"]
    readonly_fields = ["creation", "modification"]
    search_fields = ["nom", "mail"]

    def get_inscriptions(self, instance):
        return ["{} ({})".format(inscription.quartier, inscription.role, inscription.date_entree)
                 for inscription in Inscription.objects.filter(membre=instance).all()]
    get_inscriptions.short_description = 'Quartier'


@admin.register(Quartier)
class QuartierAdmin(admin.ModelAdmin):
    inlines = [InscriptionInline]
    list_display = ['nom_quartier', 'get_inscriptions', 'modification']
    list_display_links = ['nom_quartier']
    readonly_fields = ["creation", "modification"]
        
    def get_inscriptions(self, instance):
        return ["{} ({})".format(inscription.membre, inscription.role)
                 for inscription in Inscription.objects.filter(quartier=instance).all()]
    get_inscriptions.short_description = 'Membres'

@admin.register(Inscription)
class InscriptionAdmin(admin.ModelAdmin):
    list_display = ['quartier', 'membre', 'role', 'date_entree', 'date_sortie']
    list_display_links = ['quartier']
    list_filter = ["quartier", "date_entree", "role"]


