from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),

    path('membre/add', views.membre, name="add_membre"),
    path('membre/liste', views.liste_membre, name="liste_membre"),
    path('membre/membre_details/<int:member_id>', views.membre_details, name="membre_details"),
    path('membre/delete/<int:member_id>', views.member_delete, name="membre_delete"),
    path('membre/edit/<int:member_id>', views.member_update, name="membre_update"),
    path('home/', views.home, name='home'),
    path('search/', views.search, name='search'),
]
