from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.decorators import login_required, permission_required
from .forms import MembreForm
from .models import Membre, Role, Quartier, Inscription
from django.urls import reverse
from django.conf import settings
from django.template import loader, Context
from django.forms import modelformset_factory
from datetime import datetime, timedelta

MembreInscriptionFormSet = modelformset_factory(Inscription, fields=["quartier", "role", "date_entree", "date_sortie"], extra=1, can_delete=True)



@login_required
def home(request):
    return render(request, 'inscription/home.html')       

@login_required
def index(request):
    return render(request, "index.html")

@permission_required('gestion_conseils.add_membre')
def membre(request):
    if request.method == 'POST':
        membre_form = MembreForm(request.POST)
        inscription_formset = MembreInscriptionFormSet(request.POST, queryset=Inscription.objects.none())

        if membre_form.is_valid():
            membre = membre_form.save()
            
            if inscription_formset.is_valid():
                for form in inscription_formset.forms:
                    form.instance.membre = membre
                inscription_formset.save()
            else:
                print('Erreur inscription !!!')

            return redirect('liste_membre')        
        else:
            return render(request, 'membre.html', {'membre_form': membre_form, 'formset': inscription_formset })
    else:
        membre_form = MembreForm()
        inscription_formset = MembreInscriptionFormSet(queryset=Inscription.objects.none())
    
    return render(request, 'membre.html', {'membre_form': membre_form, 'formset': inscription_formset })


@login_required
@permission_required('gestion_conseils.view_membre')
def liste_membre(request):
    members = Membre.objects.all()
    roles = Role.objects.all()
    quartiers = Quartier.objects.all()

    # Récupérer les paramètres de filtrage
    quartier_id = request.GET.get('quartier')
    date_filter = request.GET.get('date')

    # Filtrer les membres en fonction des critères sélectionnés
    quartier_filter = request.GET.get('quartier')
    date_filter = request.GET.get('date')

    if quartier_filter:
        members = members.filter(quartiers__id=quartier_filter)

    if date_filter:
        if date_filter == 'week':
            date_one_week_ago = datetime.now().date() - timedelta(days=7)
            members = members.filter(creation__gte=date_one_week_ago)
        elif date_filter == 'month':
            date_one_month_ago = datetime.now().date() - timedelta(days=30)
            members = members.filter(creation__gte=date_one_month_ago)
        elif date_filter == 'year':
            date_one_year_ago = datetime.now().date() - timedelta(days=365)
            members = members.filter(creation__gte=date_one_year_ago)

    context = {
        'members': members,
        'roles': roles,
        'quartiers': quartiers,
        'selected_quartier': quartier_filter,
        'selected_date': date_filter,
    }

    return render(request, 'liste_membre.html', context)

def membre_details(request, member_id):
    member = get_object_or_404(Membre, pk=member_id)
    members = Membre.objects.all()
    roles = Role.objects.all()
    quartiers = Quartier.objects.all()
    member_inscriptions = Inscription.objects.filter(membre=member).all()

    if request.method == 'POST':
        membre_form = MembreForm(request.POST, instance=member)
        Membre( readonly=True)

        if membre_form.is_valid():
            membre = membre_form.save(commit=False)
            role = membre_form.cleaned_data['role']
            nom_quartier = membre_form.cleaned_data['nom_quartier']
            date_entree = membre_form.cleaned_data['date_entree']
            membre.save()
            membre_form.save_m2m()
            inscription = Inscription.objects.create(membre=membre, role=role, quartier=nom_quartier, date_entree=date_entree)
            return redirect('liste_membre')
    else:
        membre_form = MembreForm(instance=member)
    return render(request, 'membre_details.html', {'member': member, 'members': members, 'roles': roles, 'quartiers': quartiers,
                                                   'membre_form': membre_form, 'member_inscriptions': member_inscriptions})


def member_delete(request, member_id):
    member = get_object_or_404(Membre, pk=member_id)

    if request.method == 'POST':
        member.delete()
        return redirect('liste_membre')
    return render(request, 'membre_delete.html', {'member': member})
   
@login_required
def member_update(request, member_id):
    member = get_object_or_404(Membre, pk=member_id)
    if request.method == 'POST':
        membre_form = MembreForm(request.POST, instance=member)

        inscription_formset = MembreInscriptionFormSet(request.POST, queryset=Inscription.objects.filter(membre=member))
        if membre_form.is_valid():
            membre_form.save()
        if inscription_formset.is_valid():
            for form in inscription_formset.forms:
                form.instance.membre_id = member.id
            inscription_formset.save()

        else:
            return render(request, 'membre_update.html' , {'membre_form': membre_form, 'member': member, 'formset': inscription_formset })
        return redirect('membre_details', member_id=member.id)
    else:
        membre_form = MembreForm(instance=member)
        inscription_formset = MembreInscriptionFormSet(queryset=Inscription.objects.filter(membre=member))

    return render(request, 'membre_update.html' , {'membre_form': membre_form, 'member': member, 'formset': inscription_formset })




def search(request):
    # Check if the request is a post request.
    if request.method == 'POST':
        # Retrieve the search query entered by the user
        search = request.POST['search']
        # Filter your model by the search query
        members = Membre.objects.filter(nom__contains=search)
        return render(request, 'quartier/liste_membre.html', {'nom':search, 'members':members})
    else:
        return render(request, 'quartier/liste_membre.html',{})


