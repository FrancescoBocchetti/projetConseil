from django import forms
from django.forms.widgets import DateInput
from .models import Civilite, Membre, Quartier, Role, Inscription

class MembreForm(forms.ModelForm):

    class Meta:
        model = Membre
        fields = ['civilite', 'nom', 'prenom', 'mail', 'telephone_1', 'telephone_2', 'adr_4', 'adr_2', 'adr_3', 'adr_5', 'cp', 'ville']